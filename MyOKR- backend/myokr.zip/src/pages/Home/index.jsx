import MainLayout from "../../layout/MainLayout";

const Home = () => {
  return (
    <MainLayout>
      <div>test</div>
    </MainLayout>
  );
};

export default Home;
