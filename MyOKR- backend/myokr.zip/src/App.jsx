import Router from "./router/router";

const App = () => {
  return ( <Router/> );
}
 
export default App;